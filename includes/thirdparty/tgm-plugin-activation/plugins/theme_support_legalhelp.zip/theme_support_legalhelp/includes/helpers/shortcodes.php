<?php
//php 7.2 done
//fixed
class Bunch_Shortcodes
{
	public $keys;
	protected $base = '';
	protected $_dir = '';
	protected $_s_dir = '';
	
	
	function __construct()
	{
		//add_action('init', array( $this, 'add' ) );
		$this->add();
		
		$this->_dir = get_template_directory();
		$this->_s_dir = get_stylesheet_directory();
		
	}
	
	function add()
	{
		$this->keys = include( BUNCH_TH_ROOT.'includes/resource/shortcodes.php');
		//$this->keys = _WSH()->keys;
		
		foreach( $this->keys as $k )
		{
			//print_r($k);exit;
			$this->base = bunch_set( $k, 'base' );
			$base = $this->base;
			$this->current_atts = $k;	
			add_shortcode( bunch_set( $k, 'base' ), array( $this, 'shortcode_output' ) );
			
			if( function_exists( 'vc_map' ) ) {vc_map( $k );}
		}
		
	}
	
	function shortcode_output( $atts, $contents = null, $tag = '' )
	{
		//print_r($this->keys);exit;
		$current = bunch_set( $this->keys, $tag );
		extract( shortcode_atts( $this->create_atts($current), $atts ) );
		$file = 'includes/modules/shortcodes/'.str_replace('bunch_', '', $tag).'.php';
		$output = include( _WSH()->includes( $file ) );
		return $output;
		
		
		//if( file_exists( $this->_s_dir.$file ) ) include( $this->_s_dir.$file );
		//else include( $this->_dir.$file );
	}
	
	/** method automatically call when php search for methods */
	
	public function __call($method, $args)
	{
	   if(property_exists($this, $method)) {
		   if(is_callable($this->$method)) {
			   $args[] = $this->current_atts;
			   return call_user_func_array($this->$method, $args);
		   }
	   }
	}
	
	function create_atts( $array = array() )
	{
		//$contents = '';
		$atts = array();
		
		if( !empty ($array)){
		foreach( $array['params'] as $arr ){
			if( $arr['param_name'] == 'content' ) continue;
			
			$atts[$arr['param_name']] = bunch_set( $arr, 'default' ) ? bunch_set( $arr, 'default' ) : ''; 
		}
		}
		
		return $atts;
	}
	
	
	function excerpt( $str, $len = 35 )
	{
		return bunch_trim( $str , $len );
	}
	
}
?>