<?php
/*
Plugin Name: Theme Support
Plugin URI: http://themeforest.net/user/template_path
Description: This plugin is compatible with Legalhelp WordPress themes. 
Author: Muhibbur Rashid
Author URI: http://themebunch.com
Version: 1.0
Text Domain: BUNCH_NAME
*/
if( !defined( 'BUNCH_TH_ROOT' ) ) define('BUNCH_TH_ROOT', plugin_dir_path( __FILE__ ));
if( !defined( 'BUNCH_TH_URL' ) ) define( 'BUNCH_TH_URL', plugins_url( '', __FILE__ ) );
if( !defined( 'BUNCH_NAME' ) ) define( 'BUNCH_NAME', 'wp_legalhelp' );
include_once( 'includes/loader.php' );
function legalhelp_bunch_widget_init2()
{
	global $wp_registered_sidebars;
	$theme_options = _WSH()->option();
	if( class_exists( 'Bunch_About_us' ) )register_widget( 'Bunch_About_us' );
	if( class_exists( 'Bunch_gallery' ) )register_widget( 'Bunch_gallery' );
	if( class_exists( 'Bunch_Recent_Post' ) )register_widget( 'Bunch_Recent_Post' );
	if( class_exists( 'Bunch_Footer_contact' ) )register_widget( 'Bunch_Footer_contact' );
}
add_action( 'widgets_init', 'legalhelp_bunch_widget_init2' );	