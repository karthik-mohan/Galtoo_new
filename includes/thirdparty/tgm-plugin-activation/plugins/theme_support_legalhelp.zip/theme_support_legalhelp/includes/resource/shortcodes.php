<?php
$bunch_sc = array();
$bunch_sc['bunch_overview']	=	array(
					"name" => __("Team Overview", BUNCH_NAME),
					"base" => "bunch_overview",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Team Overview', BUNCH_NAME),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Text', BUNCH_NAME ),
							   "param_name" => "text",
							   "description" => __('Enter Your Text', BUNCH_NAME ),
							),
					)
				);
$bunch_sc['bunch_team_details']	=	array(
					"name" => __("Team Details", BUNCH_NAME),
					"base" => "bunch_team_details",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Team Details', BUNCH_NAME),
					"params" => array(
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Designation', BUNCH_NAME ),
							   "param_name" => "text",
							   "description" => __('Enter Designation', BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Text', BUNCH_NAME ),
							   "param_name" => "text1",
							   "description" => __('Enter Your Text', BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Email', BUNCH_NAME ),
							   "param_name" => "email",
							   "description" => __('Enter Your Email', BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Phone', BUNCH_NAME ),
							   "param_name" => "phone",
							   "description" => __('Enter Your Phone Number', BUNCH_NAME ),
							),
					
					)
				);

$bunch_sc['bunch_faqs']	=	array(
					"name" => __("FAQs", BUNCH_NAME),
					"base" => "bunch_faqs",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('FAQs Custom Post', BUNCH_NAME),
					"params" => array(
					   	
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						   "default" => __('This is SubTitle', BUNCH_NAME ),
						),
					/* Custom Post Set up */	
				
					//Number of Post	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number of Post', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter The Number of post to Show.', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					
					//Order By	
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Option ASC DES	
						
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Text Limit	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Set the Text Limit', BUNCH_NAME ),
						   "default" => __('20', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),	
						//
					)
				);	


$bunch_sc['bunch_map']	=	array(
					"name" => __("Google map", BUNCH_NAME),
					"base" => "bunch_map",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Google map.', BUNCH_NAME),
					"params" => array(
					   	array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Google Map Embed Code', BUNCH_NAME ),
						   "param_name" => "g_map",
						   "description" => __('Google Map Embed Code', BUNCH_NAME ),
						),
					)
				);

$bunch_sc['bunch_apointment_form']	=	array(
					"name" => __("Appointment Form", BUNCH_NAME),
					"base" => "bunch_apointment_form",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Appointment Form', BUNCH_NAME),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form7 Shortcode', BUNCH_NAME ),
						   "param_name" => "appointment_form",
						   "description" => __('Enter Contact Form7 Shortcode', BUNCH_NAME )
						),
						
					)
				);
$bunch_sc['bunch_widget_contact']	=	array(
					"name" => __("Contact Widget", BUNCH_NAME),
					"base" => "bunch_widget_contact",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Contact Widget at Contact Us Page', BUNCH_NAME),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Text', BUNCH_NAME ),
							   "param_name" => "text",
							   "description" => __('Enter Your Text', BUNCH_NAME ),
							   "default" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ullam nemo", BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Email', BUNCH_NAME ),
							   "param_name" => "email",
							   "description" => __('Enter Your Email', BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Phone', BUNCH_NAME ),
							   "param_name" => "phone",
							   "description" => __('Enter Your Phone Number', BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Fax', BUNCH_NAME ),
							   "param_name" => "fax",
							   "description" => __('Enter Your Fax', BUNCH_NAME ),
							),
						array(
							   "type" => "textarea",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Website', BUNCH_NAME ),
							   "param_name" => "web",
							   "description" => __('Enter Your Website', BUNCH_NAME ),
							),		
						 
						
						
					)
				);

$bunch_sc['bunch_contact_form']	=	array(
					"name" => __("Contact Form", BUNCH_NAME),
					"base" => "bunch_contact_form",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Contact Form at Contact Us Page', BUNCH_NAME),
					"params" => array(
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						),
						array(
						   "type" => "textarea_raw_html",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Contact Form7 Shortcode', BUNCH_NAME ),
						   "param_name" => "contact_form",
						   "description" => __('Enter Contact Form7 Shortcode', BUNCH_NAME )
						),
						
					)
				);

$bunch_sc['bunch_funfacts']	=	array(
					"name" => __("Fun Facts", BUNCH_NAME),
					"base" => "bunch_funfacts",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Fun Facts With Call to Action', BUNCH_NAME),
					"params" => array(
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('SKILLS AND EXPERIENCES', BUNCH_NAME ),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						  
						),
					//Tab1
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title1",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('SOCIAL MARKETNG', BUNCH_NAME ),
						   "group"       => __("Tab1", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number1",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('80', BUNCH_NAME ),
						   "group"       => __("Tab1", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon1",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							  "group"       => __("Tab1", BUNCH_NAME),
							 ),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link1",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						    "group"       => __("Tab1", BUNCH_NAME),
						), 
							 
					//Tab2
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title2",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('BRANDING', BUNCH_NAME ),
						   "group"       => __("Tab2", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number2",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('90', BUNCH_NAME ),
						   "group"       => __("Tab2", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon2",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							  "group"       => __("Tab2", BUNCH_NAME),
							 ),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link2",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						    "group"       => __("Tab2", BUNCH_NAME),
						), 	 
					//Tab3
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title3",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('STRATEGY PLANNING', BUNCH_NAME ),
						   "group"       => __("Tab3", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number3",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('60', BUNCH_NAME ),
						   "group"       => __("Tab3", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon3",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							  "group"       => __("Tab3", BUNCH_NAME),
							 ),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link3",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						    "group"       => __("Tab3", BUNCH_NAME),
						), 	 
						
							
						
					)
				);
$bunch_sc['bunch_service']	=	array(
					"name" => __("Practice Area/Service", BUNCH_NAME),
					"base" => "bunch_service",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Service Custom', BUNCH_NAME),
					"params" => array(
					   	
						//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						   "default" => __('This is SubTitle', BUNCH_NAME ),
						),
					/* Custom Post Set up */	
				
					//Number of Post	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number of Post', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter The Number of post to Show.', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					
					//Order By	
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Option ASC DES	
						
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Text Limit	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Set the Text Limit', BUNCH_NAME ),
						   "default" => __('20', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),	
						//
					)
				);	
$bunch_sc['bunch_call_to_action']	=	array(
					"name" => __("Call to Action", BUNCH_NAME),
					"base" => "bunch_call_to_action",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Call to Action', BUNCH_NAME),
					"params" => array(
					
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Background Image to show.", BUNCH_NAME),
						),
					 
					 //Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					//Tab-1
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title1",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('AWARD WINNING', BUNCH_NAME ),
						   "group"       => __("Tab-1", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "number1",
						   "description" => __('Enter The Number', BUNCH_NAME ),
						   "group"       => __("Tab-1", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon1",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-1", BUNCH_NAME),
							 ),
							 
						//Tab-2
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title2",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('AWARD WINNING', BUNCH_NAME ),
						   "group"       => __("Tab-2", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "number2",
						   "description" => __('Enter The Number', BUNCH_NAME ),
						   "group"       => __("Tab-2", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon2",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-2", BUNCH_NAME),
							 ),
						//Tab-3
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title3",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('AWARD WINNING', BUNCH_NAME ),
						   "group"       => __("Tab-3", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number', BUNCH_NAME ),
						   "param_name" => "number3",
						   "description" => __('Enter The Number', BUNCH_NAME ),
						   "group"       => __("Tab-3", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon3",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-3", BUNCH_NAME),
							 ),
					)
				);

$bunch_sc['bunch_blog']	=	array(
					"name" => __("Blog", BUNCH_NAME),
					"base" => "bunch_blog",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Blog', BUNCH_NAME),
					"params" => array(
					   	
						//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						  
						),
					/* Custom Post Set up */	
				
					//Number of Post	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number of Post', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter The Number of post to Show.', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),
						//Number of Column
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Column", BUNCH_NAME),
						   "param_name" => "layout",
						   'value' => array_flip(array('2'=>__('2', BUNCH_NAME),'3'=>__('3', BUNCH_NAME),'4'=>__('4', BUNCH_NAME) ) ),			
						   "description" => __("Set the number of Column to show", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Order By	
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Option ASC DES	
						
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Text Limit	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Set the Text Limit', BUNCH_NAME ),
						   "default" => __('20', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),	
						//
					)
				);	

$bunch_sc['bunch_team']	=	array(
					"name" => __("Team", BUNCH_NAME),
					"base" => "bunch_team",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Team', BUNCH_NAME),
					"params" => array(
					   	
					array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Column", BUNCH_NAME),
						   "param_name" => "layout",
						   'value' => array_flip(array('2'=>__('2', BUNCH_NAME),'3'=>__('3', BUNCH_NAME),'4'=>__('4', BUNCH_NAME) ) ),			
						   "description" => __("Set the number of Column to show", BUNCH_NAME),
						   "group"       => __("Basic", BUNCH_NAME),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Column", BUNCH_NAME),
						   "param_name" => "location",
						   'value' => array_flip(array('1'=>__('Image Left', BUNCH_NAME),'2'=>__('Image Top', BUNCH_NAME) ) ),			
						   "description" => __("Set the number of Column to show", BUNCH_NAME),
						   "group"       => __("Basic", BUNCH_NAME),
						),
					
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						),
					/* Custom Post Set up */	
				
					//Number of Post	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number of Post', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter The Number of post to Show.', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Order By	
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Option ASC DES	
						
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Text Limit	
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Set the Text Limit', BUNCH_NAME ),
						   "default" => __('20', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						
						//
					)
				);	

$bunch_sc['bunch_client']	=	array(
					"name" => __("Client", BUNCH_NAME),
					"base" => "bunch_client",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Clients', BUNCH_NAME),
					"params" => array(
					   	
						//
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image1",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link1",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image2",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link2",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image3",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link3",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image4",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link4",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image5",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link5",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image6",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link6",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image7",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link7",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image8",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link8",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image9",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link9",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//Image
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image10",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link10",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						//
					)
				);	
$bunch_sc['bunch_parallax_two']	=	array(
					"name" => __("Parallax Two", BUNCH_NAME),
					"base" => "bunch_parallax_two",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Parallax Two', BUNCH_NAME),
					"params" => array(
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Sub Title', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor sit amet", BUNCH_NAME ),
						),
						
						
					)
				);
$bunch_sc['bunch_testimonial']	=	array(
					"name" => __("Testimonial", BUNCH_NAME),
					"base" => "bunch_testimonial",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Show Testimonial.', BUNCH_NAME),
					"params" => array(
					   	
					//Title
						array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Title', BUNCH_NAME ),
							   "param_name" => "title",
							   "description" => __('Enter section Title', BUNCH_NAME ),
							   "default" => __('This is Title', BUNCH_NAME ),
							),
							
						array(
							   "type" => "textfield",
							   "holder" => "div",
							   "class" => "",
							   "heading" => __('Sub Title', BUNCH_NAME ),
							   "param_name" => "sub_title",
							   "description" => __('Enter section Sub Title', BUNCH_NAME ),
							   "default" => __('This is Sub Title', BUNCH_NAME ),
							),
					
					
						//Custom Area
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text Limit', BUNCH_NAME ),
						   "param_name" => "text_limit",
						   "description" => __('Enter Number of Text Limit to Show.', BUNCH_NAME )
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Number of Post', BUNCH_NAME ),
						   "param_name" => "num",
						   "description" => __('Enter Number of Slides to Show.', BUNCH_NAME ),
						   "group"       => __("Custom", BUNCH_NAME),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __( 'Category', BUNCH_NAME ),
						   "param_name" => "cat",
						   "value" => array_flip( (array)bunch_get_categories( array( 'taxonomy' => 'testimonials_category', 'hide_empty' => FALSE ), true ) ),
						   "description" => __( 'Choose Category.', BUNCH_NAME ),
						    "group"       => __("Custom", BUNCH_NAME),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order By", BUNCH_NAME),
						   "param_name" => "sort",
						   'value' => array_flip( array('date'=>__('Date', BUNCH_NAME),'title'=>__('Title', BUNCH_NAME) ,'name'=>__('Name', BUNCH_NAME) ,'author'=>__('Author', BUNCH_NAME),'comment_count' =>__('Comment Count', BUNCH_NAME),'random' =>__('Random', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						    "group"       => __("Custom", BUNCH_NAME),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Order", BUNCH_NAME),
						   "param_name" => "order",
						   'value' => array_flip(array('ASC'=>__('Ascending', BUNCH_NAME),'DESC'=>__('Descending', BUNCH_NAME) ) ),			
						   "description" => __("Enter the sorting order.", BUNCH_NAME),
						   "group"       => __("Custom", BUNCH_NAME),
						),
					)
				);	


$bunch_sc['bunch_accordion']	=	array(
					"name" => __("Accordion", BUNCH_NAME),
					"base" => "bunch_accordion",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Accordion', BUNCH_NAME),
					"params" => array(
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Set the Title', BUNCH_NAME ),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Number of Row", BUNCH_NAME),
						   "param_name" => "layout",
						   'value' => array_flip(array('2'=>__('2', BUNCH_NAME),'3'=>__('3', BUNCH_NAME),'4'=>__('4', BUNCH_NAME),'5'=>__('5', BUNCH_NAME),'6'=>__('6', BUNCH_NAME) ) ),			
						   "description" => __("Select the number of  Column to show", BUNCH_NAME),
						),
					//Tab1
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title1",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('SOCIAL MARKETNG', BUNCH_NAME ),
						   "group"       => __("Tab1", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "number1",
						   "description" => __('Set the Text', BUNCH_NAME ),
						   "group"       => __("Tab1", BUNCH_NAME),
						),
					//Tab2
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title2",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('BRANDING', BUNCH_NAME ),
						   "group"       => __("Tab2", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "number2",
						   "description" => __('Set the Text', BUNCH_NAME ),
						  
						   "group"       => __("Tab2", BUNCH_NAME),
						),
					//Tab3
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title3",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('STRATEGY PLANNING', BUNCH_NAME ),
						   "group"       => __("Tab3", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "number3",
						   "description" => __('Set the Text', BUNCH_NAME ),
						  
						   "group"       => __("Tab3", BUNCH_NAME),
						),
						
					//Tab4
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title4",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('WEBSITE ANALYSIS', BUNCH_NAME ),
						   "group"       => __("Tab4", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "number4",
						   "description" => __('Set the Text', BUNCH_NAME ),
						   "group"       => __("Tab4", BUNCH_NAME),
						),
					//Tab5
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title5",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('WEBSITE ANALYSIS', BUNCH_NAME ),
						   "group"       => __("Tab5", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "number5",
						   "description" => __('Set the Text', BUNCH_NAME ),
						   "group"       => __("Tab5", BUNCH_NAME),
						),
					//Tab6
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title6",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('WEBSITE ANALYSIS', BUNCH_NAME ),
						   "group"       => __("Tab6", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "number6",
						   "description" => __('Set the Text', BUNCH_NAME ),
						   "group"       => __("Tab6", BUNCH_NAME),
						),		
						
					)
				);
$bunch_sc['bunch_our_skills']	=	array(
					"name" => __("Our Skills", BUNCH_NAME),
					"base" => "bunch_our_skills",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Skills With Percentage', BUNCH_NAME),
					"params" => array(
					 	array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('SKILLS AND EXPERIENCES', BUNCH_NAME ),
						),
						array(
						   "type" => "dropdown",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Select Number of Row", BUNCH_NAME),
						   "param_name" => "layout",
						   'value' => array_flip(array('2'=>__('2', BUNCH_NAME),'3'=>__('3', BUNCH_NAME),'4'=>__('4', BUNCH_NAME),'5'=>__('5', BUNCH_NAME),'6'=>__('6', BUNCH_NAME) ) ),			
						   "description" => __("Select the number of  Column to show", BUNCH_NAME),
						),
					//Tab1
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title1",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('SOCIAL MARKETNG', BUNCH_NAME ),
						   "group"       => __("Tab1", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number1",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('80', BUNCH_NAME ),
						   "group"       => __("Tab1", BUNCH_NAME),
						),
					//Tab2
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title2",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('BRANDING', BUNCH_NAME ),
						   "group"       => __("Tab2", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number2",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('90', BUNCH_NAME ),
						   "group"       => __("Tab2", BUNCH_NAME),
						),
					//Tab3
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title3",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('STRATEGY PLANNING', BUNCH_NAME ),
						   "group"       => __("Tab3", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number3",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('60', BUNCH_NAME ),
						   "group"       => __("Tab3", BUNCH_NAME),
						),
						
					//Tab4
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title4",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('WEBSITE ANALYSIS', BUNCH_NAME ),
						   "group"       => __("Tab4", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number4",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('88', BUNCH_NAME ),
						   "group"       => __("Tab4", BUNCH_NAME),
						),
					//Tab5
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title5",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('WEBSITE ANALYSIS', BUNCH_NAME ),
						   "group"       => __("Tab5", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number5",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('88', BUNCH_NAME ),
						   "group"       => __("Tab5", BUNCH_NAME),
						),
					//Tab6
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title6",
						   "description" => __('Set the Title', BUNCH_NAME ),
						   "default" => __('WEBSITE ANALYSIS', BUNCH_NAME ),
						   "group"       => __("Tab6", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Percentage', BUNCH_NAME ),
						   "param_name" => "number6",
						   "description" => __('Set the Percentage Number', BUNCH_NAME ),
						   "default" => __('88', BUNCH_NAME ),
						   "group"       => __("Tab6", BUNCH_NAME),
						),		
						
					)
				);
$bunch_sc['bunch_practice_block_three']	=	array(
					"name" => __("Practice Four Column Icon", BUNCH_NAME),
					"base" => "bunch_practice_block_three",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Practice Four Column No Image', BUNCH_NAME),
					"params" => array(
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ullam nemo", BUNCH_NAME ),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 ),
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),	 
					)
				);				
				
$bunch_sc['bunch_practice_block_two']	=	array(
					"name" => __("Practice Block Two", BUNCH_NAME),
					"base" => "bunch_practice_block_two",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Practice Area Block No Image', BUNCH_NAME),
					"params" => array(
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ullam nemo", BUNCH_NAME ),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 ),
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),	 
					)
				);				

$bunch_sc['bunch_practice_four_col']	=	array(
					"name" => __("Practice Four Column Image", BUNCH_NAME),
					"base" => "bunch_practice_four_col",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Practice Four Column Block ', BUNCH_NAME),
					"params" => array(
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ullam nemo", BUNCH_NAME ),
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 ),
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),	 
					)
				);				
				
$bunch_sc['bunch_practice_block']	=	array(
					"name" => __("Practice Block", BUNCH_NAME),
					"base" => "bunch_practice_block",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Practice Area Block ', BUNCH_NAME),
					"params" => array(
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ullam nemo", BUNCH_NAME ),
						),
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 ),
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),	 
					)
				);
$bunch_sc['bunch_title_block']	=	array(
					"name" => __("Section Title", BUNCH_NAME),
					"base" => "bunch_title_block",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Section Title', BUNCH_NAME),
					"params" => array(
					//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
					//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						   "default" => __('This is SubTitle', BUNCH_NAME ),
						),
						
					)
				);
$bunch_sc['bunch_parallax']	=	array(
					"name" => __("Parallax", BUNCH_NAME),
					"base" => "bunch_parallax",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Parallax One', BUNCH_NAME),
					"params" => array(
						array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "default" => __('Read More  ', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor sit amet, consectetur adipisicing elit. Blanditiis ullam nemo", BUNCH_NAME ),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text1",
						   "description" => __('Linked Text', BUNCH_NAME ),
						   "default" => __("Lorem ipsum dolor", BUNCH_NAME ),
						),
						
					)
				);
$bunch_sc['bunch_service_round']	=	array(
					"name" => __("Service One", BUNCH_NAME),
					"base" => "bunch_service_round",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Service Round Icon', BUNCH_NAME),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 ),
					)
				);
$bunch_sc['bunch_featured_single']	=	array(
					"name" => __("Featured Single", BUNCH_NAME),
					"base" => "bunch_featured_single",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Featured Single', BUNCH_NAME),
					"params" => array(
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Keeping a well-maintained vehicle is", BUNCH_NAME ),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 ),
					)
				);

$bunch_sc['bunch_featured_one']	=	array(
					"name" => __("Featured Block", BUNCH_NAME),
					"base" => "bunch_featured_one",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Featured Block Group With Button', BUNCH_NAME),
					"params" => array(
					   	
				//
				//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
					//Tab-1
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title1",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						   "group"       => __("Tab-1", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text1",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Keeping a well-maintained vehicle is", BUNCH_NAME ),
						    "group"       => __("Tab-1", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon1",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-1", BUNCH_NAME),
							 ),
						//Tab-2
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title2",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						   "group"       => __("Tab-2", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text2",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Keeping a well-maintained vehicle is", BUNCH_NAME ),
						   "group"       => __("Tab-2", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon2",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-2", BUNCH_NAME),
							 ),
						//Tab-3
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title3",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						   "group"       => __("Tab-3", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text3",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Keeping a well-maintained vehicle is", BUNCH_NAME ),
						   "group"       => __("Tab-3", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon3",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-3", BUNCH_NAME),
							 ),
						//Tab-4
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title4",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						   "default" => __('This is Title', BUNCH_NAME ),
						   "group"       => __("Tab-4", BUNCH_NAME),
						),
						array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Text', BUNCH_NAME ),
						   "param_name" => "text4",
						   "description" => __('Enter Your Text', BUNCH_NAME ),
						   "default" => __("Keeping a well-maintained vehicle is", BUNCH_NAME ),
						   "group"       => __("Tab-4", BUNCH_NAME),
						),
						array(
							"type" => "dropdown",
							 "holder" => "div",
							 "class" => "",
							 "heading" => __("Icon", BUNCH_NAME),
							 "param_name" => "icon4",
							 "value" => (array)vp_get_fontawesome_icons(),
							 "description" => __("Choose Icon", BUNCH_NAME),
							 "group"       => __("Tab-4", BUNCH_NAME),
							 ),	
						//Button & Link
						 array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button', BUNCH_NAME ),
						   "param_name" => "btn",
						   "description" => __('Enter Button Text', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),
						array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Button Link', BUNCH_NAME ),
						   "param_name" => "link",
						   "description" => __('Enter Button Link', BUNCH_NAME ),
						   "group"       => __("Button", BUNCH_NAME),
						),	 
						//
					)
				);

$bunch_sc['bunch_welcome_block']	=	array(
					"name" => __("Welcome Block", BUNCH_NAME),
					"base" => "bunch_welcome_block",
					"class" => "",
					"category" => __('Legal Help', BUNCH_NAME),
					"icon" => 'fa-briefcase' ,
					'description' => __('Welcome Block Home One', BUNCH_NAME),
					"params" => array(
					   	
						//
				//Title
					array(
						   "type" => "textfield",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('Title', BUNCH_NAME ),
						   "param_name" => "title",
						   "description" => __('Enter The Section Title', BUNCH_NAME ),
						),
				//SubTitle
					array(
						   "type" => "textarea",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __('SubTitle', BUNCH_NAME ),
						   "param_name" => "sub_title",
						   "description" => __('Enter The Section SubTitle', BUNCH_NAME ),
						),
				//Image
					array(
						   "type" => "attach_image",
						   "holder" => "div",
						   "class" => "",
						   "heading" => __("Image", BUNCH_NAME),
						   "param_name" => "image",
						   "description" => __("Enter the Image to show.", BUNCH_NAME),
						),	
						//
					)
				);
/*----------------------------------------------------------------------------*/
$bunch_sc = apply_filters( '_bunch_shortcodes_array', $bunch_sc );
	
return $bunch_sc;